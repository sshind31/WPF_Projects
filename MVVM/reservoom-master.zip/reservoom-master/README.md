# Reservoom

A simple hotel reservation system demonstrating WPF MVVM fundamentals.

Follow along at https://youtube.com/playlist?list=PLA8ZIAm2I03hS41Fy4vFpRw8AdYNBXmNm.

See [branches](https://github.com/SingletonSean/reservoom/branches) to view the state of the repository at the end of an episode.
